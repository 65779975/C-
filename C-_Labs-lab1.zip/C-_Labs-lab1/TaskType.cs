﻿
namespace Pz1.TaskSystem
{
    internal enum TaskType
    {
        None = 2,
        Task3 = 3,
        Task4 = 4,
        Exit = 5,
    }
}